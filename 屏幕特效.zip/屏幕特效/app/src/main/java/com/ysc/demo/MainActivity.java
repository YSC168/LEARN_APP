package com.ysc.demo;

import android.app.*;
import android.os.*;
import android.widget.Button;
import android.view.View.OnClickListener;
import android.view.View;
import android.content.Intent;
import com.android.permission.*;
public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		FloatWindowManager.getInstance().applyOrShowFloatWindow(MainActivity.this);

		
		//FloatingWindowActivity的布局视图按钮
        Button start = (Button)findViewById(R.id.start_id);

        Button remove = (Button)findViewById(R.id.remove_id);

        start.setOnClickListener(new OnClickListener()
			{

				@Override
				public void onClick(View v)
				{
					// TODO Auto-generated method stub
					Intent intent = new Intent(MainActivity.this, TxService.class);
					startService(intent);
				
				}
			});

        remove.setOnClickListener(new OnClickListener()
			{

				@Override
				public void onClick(View v)
				{
					Intent intent = new Intent(MainActivity.this, TxService.class);
					stopService(intent);
				}
			});
		
			
    }
}
