package com.learn.app;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.app.*;
import android.os.*;
import android.widget.Button;
import android.view.View.OnClickListener;
import android.view.View;
import android.content.Intent;
import android.view.*;
import android.widget.*;
import android.content.*;
import java.util.*;
import com.bumptech.glide.*;

public class Splash extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		//设置全屏
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, 
							 WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash);
		int i = new Random().nextInt(ConstantsImageUrl.DIYTRANSITION_URLS.length);
		ImageView iv=(ImageView) findViewById(R.id.splash_iv_pic);
		Glide.with(this)
			.load(ConstantsImageUrl.DIYTRANSITION_URLS[i])
		//.load(ConstantsImageUrl.HOME_SIX_URLS[i])
			.placeholder(R.drawable.error)
			.error(R.drawable.jiazai)
			.into(iv);
		//显示计时器
		Timer timer=new Timer();
		//设置启动时间
		timer.schedule(task,2500);
	}
	//实例化
	TimerTask task=new TimerTask(){
        //开始运行
		@Override
		public void run()
		{
			Intent intent=new Intent(Splash.this,MainActivity.class);
			startActivity(intent);
			overridePendingTransition(R.anim.screen_zoom_in, R.anim.screen_zoom_out);
			finish();
		}}; 
}
