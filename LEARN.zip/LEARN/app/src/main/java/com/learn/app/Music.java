package com.learn.app;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.net.*;
import android.view.*;
import android.widget.*;
import android.widget.SeekBar.*;
import com.download.*;
import java.io.*;
import java.net.*;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.webkit.*;
import android.support.design.widget.*;
import java.util.*;
public class Music extends Fragment implements OnClickListener
{
	private static final int PROCESSING = 1;
	private static final int FAILURE = -1;
	private DownloadTask task;
	private EditText pathText;
	private TextView resultView;
	private Button startdownload;
	private Button pausedownload;
	private ProgressBar progressBar;
	private Button playBtn;
	private Button pauseBtn;
	private Button webmusic;
	private Player player;
	private SeekBar musicProgress;
	private Handler handler = new UIHandler();

	private final class UIHandler extends Handler {
		public void handleMessage(Message msg) {
			switch (msg.what) {
				case PROCESSING: 
					progressBar.setProgress(msg.getData().getInt("size"));
					float num = (float) progressBar.getProgress()/ (float) progressBar.getMax();
					int result = (int) (num * 100); 
					resultView.setText(result + "%");
					if (progressBar.getProgress() == progressBar.getMax()) { 
						Snackbar.make(playBtn, "音乐保存在sdcard/YSC_APP/音乐", Snackbar.LENGTH_LONG).show();
					}
					break;
				case FAILURE:
					Snackbar.make(playBtn, "下载出错", Snackbar.LENGTH_LONG).show();
					//QQToast.makeText(getActivity(),"下载出错");
					//Toast.makeText(getActivity(), "下载出错", Toast.LENGTH_LONG).show();
					break;
			}
		}
	}
	
	@Override
	public void onClick(View p1)
	{
		// TODO: Implement this method
	}
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
		return inflater.inflate(R.layout.music, container, false);
	}
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
		//setHasOptionsMenu(true);
		pathText = (EditText)this.getActivity().findViewById(R.id.path);
		resultView = (TextView) this.getActivity().findViewById(R.id.resultView);
		startdownload = (Button) this.getActivity().findViewById(R.id.download);
		pausedownload = (Button) this.getActivity().findViewById(R.id.pausebutton);
		progressBar = (ProgressBar) this.getActivity().findViewById(R.id.progressBar);
		playBtn = (Button) this.getActivity().findViewById(R.id.btn_play);
		pauseBtn = (Button) this.getActivity().findViewById(R.id.btn_pause);
		musicProgress = (SeekBar) this.getActivity().findViewById(R.id.music_progress);
		player = new Player(musicProgress);
		musicProgress.setOnSeekBarChangeListener(new SeekBarChangeEvent());
		webmusic = (Button) getActivity().findViewById(R.id.webmusic);
        webmusic.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					LayoutInflater inflater = LayoutInflater.from(getActivity());
					View view = inflater.inflate(R.layout.webview, null);
					final WebView mWebview = (WebView) view.findViewById(R.id.webview);
					mWebview.getSettings().setJavaScriptEnabled(true);
					mWebview.requestFocus();
					mWebview.setScrollBarStyle(0);
					mWebview.getSettings().setAllowFileAccess(true);
					mWebview.setWebViewClient(new WebViewClient(){
							@Override
							public boolean shouldOverrideUrlLoading(WebView view, String url) {
								view.loadUrl(url);
								return true;
							}
						});
					mWebview.loadUrl("http://music.liuzhijin.cn/");
					AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
					builder.setView(view);
					builder.show();
				}
			});
		startdownload.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					String path = pathText.getText().toString();
					if (Environment.getExternalStorageState().equals(
							Environment.MEDIA_MOUNTED)) {
						File temp = new File("/sdcard/YSC_APP/音乐/");//要保存文件先创建文件夹   
						if (!temp.exists()) {
							temp.mkdir();
						}

						File file=new File(temp+ "/");//将要保存音乐的路径
						download(path, file);
					} else {
						Toast.makeText(getActivity(), "error", Toast.LENGTH_LONG).show();

					}
					startdownload.setEnabled(false);
					pausedownload.setEnabled(true);
					
			}});
    	pausedownload.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					exit();
					Snackbar.make(playBtn, "已暂停", Snackbar.LENGTH_LONG).show();
					startdownload.setEnabled(true);
					pausedownload.setEnabled(false);

				}});
		pauseBtn.setOnClickListener(new OnClickListener() {

				private boolean isPause;
				@Override
				public void onClick(View v) {
					if(!isPause){
						player.pause();
						isPause = true;
						pauseBtn.setText("继续");
					}else{
						player.play();
						pauseBtn.setText("暂停");
						isPause = false;
					}
				}});
		playBtn.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					new Thread(new Runnable() {

							@Override
							public void run() {
								player.playUrl(pathText.getText().toString());
							}
						}).start();

				}});
	}

	@Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.color, menu);
        super.onCreateOptionsMenu(menu, inflater);

    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
		if (id == R.id.two ){

		}
        if (id == R.id.three ) {

            return true;
        } else
            return super.onOptionsItemSelected(item);

    }
	private void exit() {
		if (task != null)
			task.exit();
	}

	private void download(String path, File savDir) {
		task = new DownloadTask(path, savDir);
		new Thread(task).start();
	}

	private final class DownloadTask implements Runnable {
		private String path;
		private File saveDir;
		private FileDownloader loader;
		public DownloadTask(String path, File saveDir) {
			this.path = path;
			this.saveDir = saveDir;
		}
		public void exit() {
			if (loader != null)
				loader.exit();
		}

		DownloadProgressListener downloadProgressListener = new DownloadProgressListener() {
			@Override
			public void onDownloadSize(int size) {
				Message msg = new Message();
				msg.what = PROCESSING;
				msg.getData().putInt("size", size);
				handler.sendMessage(msg);
			}
		};

		public void run() {
			try {
				loader = new FileDownloader(getActivity().getApplicationContext(), path,
											saveDir, 3);
				progressBar.setMax(loader.getFileSize());
				loader.download(downloadProgressListener);
			} catch (Exception e) {
				e.printStackTrace();
				handler.sendMessage(handler.obtainMessage(FAILURE)); 
			}
		}
	}	class SeekBarChangeEvent implements OnSeekBarChangeListener {
		int progress;

		@Override
		public void onProgressChanged(SeekBar seekBar, int progress,
									  boolean fromUser) {
	
			this.progress = progress * player.mediaPlayer.getDuration()/ seekBar.getMax();
		}

		@Override
		public void onStartTrackingTouch(SeekBar seekBar) {

		}

		@Override
		public void onStopTrackingTouch(SeekBar seekBar) {
			player.mediaPlayer.seekTo(progress);
		}
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		if (player != null) {
			player.stop();
			player = null;
		}
	}
	
	public void yin(View p1)
	{
		Intent intent_d=new Intent();
		intent_d.setAction("android.intent.action.VIEW");
		Uri content_url=Uri.parse("http://v.youku.com/v_show/id_XMjc0ODA0MTA0NA==.html?spm=a2h3j.8428770.3416059.1");
		intent_d.setData(content_url);
		startActivity(intent_d);
	}
}
