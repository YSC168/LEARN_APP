package com.learn.app;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import java.util.ArrayList;
import java.util.Random;
import java.util.List;
import android.view.*;
import android.support.v4.widget.*;
import android.graphics.*;

public class ColorMain extends Fragment implements OnClickListener
{
	@Override
	public void onClick(View p1)
	{
		// TODO: Implement this method
	}

	private ColorList[] xingzhuo = {new ColorList("双子座", R.drawable.image_1)};
    public List<ColorList> xingzhuoList = new ArrayList<>();
    public ColorListAdapter adapter;
	private SwipeRefreshLayout swipeRefresh;
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
		return inflater.inflate(R.layout.colorlist, container, false);
	}
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
		setHasOptionsMenu(true);
		initFruits();
        RecyclerView recyclerView = (RecyclerView) getActivity().findViewById(R.id.recycler_view);
        GridLayoutManager layoutManager = new GridLayoutManager(getActivity(), 3);//this
        recyclerView.setLayoutManager(layoutManager);
        adapter = new ColorListAdapter(xingzhuoList);
        recyclerView.setAdapter(adapter);
		swipeRefresh = (SwipeRefreshLayout) getActivity().findViewById(R.id.swipe_refresh);
        
        swipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
				@Override
				public void onRefresh() {
					swipeRefresh.setColorSchemeColors(getRandomColor());
					refreshFruits();
				}
			});
       }
	private void refreshFruits() {
					new Thread(new Runnable() {
							@Override
							public void run() {
								initFruits();
								adapter.notifyDataSetChanged();
								swipeRefresh.setRefreshing(false);
							}
						}).start();
    }
	@Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.color, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
		if (id == R.id.two ){
			RecyclerView recyclerView = (RecyclerView) getActivity().findViewById(R.id.recycler_view);
			GridLayoutManager layoutManager = new GridLayoutManager(getActivity(), 2);//this
			recyclerView.setLayoutManager(layoutManager);
		}
        if (id == R.id.three ) {
			RecyclerView recyclerView = (RecyclerView) getActivity().findViewById(R.id.recycler_view);
			GridLayoutManager layoutManager = new GridLayoutManager(getActivity(), 3);//this
			recyclerView.setLayoutManager(layoutManager);
            return true;
        } else
            return super.onOptionsItemSelected(item);
    }
	private void initFruits() {
        xingzhuoList.clear();
        for (int i = 0; i < 540; i++) {
            Random random = new Random();
            int index = random.nextInt(xingzhuo.length);
            xingzhuoList.add(xingzhuo[index]);
        }
    }
	public int getRandomColor() {
        Random rand = new Random();
        return Color.argb(rand.nextInt(256), rand.nextInt(256), rand.nextInt(256), rand.nextInt(256));

    }
	   }

