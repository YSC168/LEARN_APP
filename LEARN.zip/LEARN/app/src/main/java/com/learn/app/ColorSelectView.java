package com.learn.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import com.learn.app.*;

public class ColorSelectView extends View {
    private Paint circlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int width, height, childWidth, childHeight, radius;
    private int count = 3;
    private int touchX, touchY;
    private boolean isTouch = false;
    private int number = -1;
    private static final double manager_left = 0.15;
    private static final double manager = 0.25;
    private Bitmap bitmap;
    private int bitmapWidth;
    private onColorSelectClickListener onColorSelectClickListener;
    public ColorSelectView.onColorSelectClickListener getOnColorSelectClickListener() {
        return onColorSelectClickListener;
    }

    public void setOnColorSelectClickListener(ColorSelectView.onColorSelectClickListener onColorSelectClickListener) {
        this.onColorSelectClickListener = onColorSelectClickListener;
    }

    public interface onColorSelectClickListener {
        void OnClick(int color);
    }

    public ColorSelectView(Context context) {
        super(context, null);
    }

    public ColorSelectView(Context context, AttributeSet attrs) {
        super(context, attrs, 0);
    }

    public ColorSelectView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        int widthSize = MeasureSpec.getSize(widthMeasureSpec);
        int hetghtSize = MeasureSpec.getSize(heightMeasureSpec);
        init(widthSize, hetghtSize);
    }

    private void init(int widthSize, int hetghtSize) {
        width = widthSize;
        height = hetghtSize;
        childWidth = widthSize / count;
        childHeight = hetghtSize / count;
        radius = (int) (childWidth * manager);
        circlePaint.setAntiAlias(true);
        circlePaint.setStyle(Paint.Style.FILL);
        textPaint.setAntiAlias(true);
        textPaint.setTextSize(radius / 2);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setStyle(Paint.Style.FILL);
        bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_check);
        Matrix matrix = new Matrix();
        matrix.setScale(0.5f, 0.5f);
        bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
        bitmapWidth = bitmap.getWidth();
    }

    @Override
    public void draw(Canvas canvas) {
        super.draw(canvas);
        drawCircle(canvas);
        drawBorder(canvas);
    }

    private void drawCircle(Canvas canvas) {
        int endY;
        for (int i = 0; i < count; i++)
            for (int j = 0; j < count; j++) {
                circlePaint.setColor(getResources().getColor(DefaultUtils.color[j * count + i]));
                textPaint.setColor(getResources().getColor(DefaultUtils.color[j * count + i]));
                canvas.drawCircle(i * childWidth + childWidth / 2,
								  j * childHeight + childHeight / 2,
								  radius, circlePaint);
                endY = (int) ((j * childHeight) + childHeight * manager_left + 2 * radius);
                canvas.drawText(DefaultUtils.textTheme[j * count + i], i * childWidth + childWidth / 2
								, endY + childWidth / 4, textPaint);
            }
    }

    private void drawBorder(Canvas canvas) {
        number = getTouchNumber(touchX, touchY);
        int pos[] = getLineXY(number);
        if (isTouch) {
            canvas.drawBitmap(bitmap, pos[0] * childWidth + childWidth / 2 - bitmapWidth / 2,
							  pos[1] * childHeight + childHeight / 2 - bitmapWidth / 2, null);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int downX, downY, moveX, movwY, upX, upY;
        if (event.getAction() == event.ACTION_DOWN) {
            invalidate();
            downX = (int) event.getX();
            downY = (int) event.getY();
            if (isTouchNumber(downX, downY)) {
                isTouch = true;
                touchX = downX;
                touchY = downY;
            }
        } else if (event.getAction() == event.ACTION_MOVE) {

        } else if (event.getAction() == event.ACTION_UP) {
            upX = (int) event.getX();
            upY = (int) event.getY();
            if (isTouchNumber(upX, upY)) {
                if (onColorSelectClickListener != null && number != -1)
                    onColorSelectClickListener.OnClick(getResources().getColor(DefaultUtils.color[number]));
            }
            isTouch = false;
        }
        return true;
    }

    private int[] getLineXY(int number) {
        int i, j = 0;
        for (int x = 0; x < count; x++) {
            if (number >= x * count && number <= (x + 1) * count - 1)
                j = x;
        }
        i = number - j * count;
        return new int[]{i, j};
    }

    private boolean isTouchNumber(int x, int y) {
        if (getTouchNumber(x, y) != -1)
            return true;
        else
            return false;
    }

    private int getTouchNumber(int x, int y) {
        int startX, startY, endX, endY;
        for (int i = 0; i < count; i++)
            for (int j = 0; j < count; j++) {
                startX = (int) ((i * childWidth) + childWidth * manager_left);
                startY = (int) ((j * childHeight) + childHeight * manager_left);
                endX = (int) ((i * childWidth) + childWidth * manager_left + 2 * radius);
                endY = (int) ((j * childHeight) + childHeight * manager_left + 2 * radius);
                if (x > startX && x < endX && y > startY && y < endY)
                    return (j * count + i);
            }
        return -1;
    }
}

