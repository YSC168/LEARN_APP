package com.learn.app;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import com.learn.app.*;

public class ColorSelectFragment extends DialogFragment {
    private View rootView;
    private ColorSelectView colorSelectView;
    private Button ok, cancel;
    private onOkClickListener onOkClickListener;
    private int newColor = 0;

    public ColorSelectFragment.onOkClickListener getOnOkClickListener() {
        return onOkClickListener;
    }

    public void setOnOkClickListener(ColorSelectFragment.onOkClickListener onOkClickListener) {
        this.onOkClickListener = onOkClickListener;
    }

    public interface onOkClickListener {
        void onClick(View v, int color);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        init();
        rootView = inflater.inflate(R.layout.dialog_colorselect, container, false);
        initView(rootView);
        return rootView;
    }

    private void init() {
        getDialog().getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        getDialog().setCanceledOnTouchOutside(true);
    }

    private void initView(View rootView) {
        colorSelectView = (ColorSelectView) rootView.findViewById(R.id.dialog_colorselect);
        colorSelectView.setOnColorSelectClickListener(new ColorSelectView.onColorSelectClickListener() {
				@Override
				public void OnClick(int color) {
					newColor = color;
				}
			});
        ok = (Button) rootView.findViewById(R.id.dialog_colorselect_ok);
        ok.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					if (newColor != 0)
						if (onOkClickListener != null)
							onOkClickListener.onClick(v, newColor);
					dismiss();
				}
			});
        cancel = (Button) rootView.findViewById(R.id.dialog_colorselect_cancel);
        cancel.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					dismiss();
				}
			});
    }
}

