package com.learn.app;


import java.util.ArrayList;

/**
 *
 * 登录到期时间 2018-01-18 需重新登录
 * .bkt.clouddn.com为新创建存储空间后系统默认为用户生成的测试域名，此类测试域名，限总流量，限单 IP 访问频率，限速，仅供测试使用。
 * 单IP每秒限制请求次数10次，大于10次403禁止5秒。
 * 单url限速8Mbps，下载到10MB之后，限速1Mbps。
 *
 *
 * Author: nanchen
 * Email: liushilin520@foxmail.com
 * Date: 2017-04-07  15:06
 */

public class ConstantsImageUrl {
    // 电影栏头部的图片
    public static final String ONE_URL_01 = "http://ojyz0c8un.bkt.clouddn.com/one_01.png";

    // 头像
    public static final String IC_AVATAR = "http://ojyz0c8un.bkt.clouddn.com/ic_avatar.png";
	
    // 过渡图的图片链接
 
    private static final String DIYTRANSITION_URL_01 = "http://img03.sogoucdn.com/app/a/100520146/39975154cacde19b676f048bc7926381";
    private static final String DIYTRANSITION_URL_02 = "http://img02.sogoucdn.com/app/a/100520146/b95846d9de145cc811465df2693a7250";
    private static final String DIYTRANSITION_URL_03 = "http://img02.sogoucdn.com/app/a/100520146/2c0e80d10d45e943575e812ff6e4e350";
    private static final String DIYTRANSITION_URL_04 = "http://img01.sogoucdn.com/app/a/100520146/7b05d4fb82c54ed51dcb2e997f884fd3" ;
    private static final String DIYTRANSITION_URL_05 = "http://img04.sogoucdn.com/app/a/100520146/0a4e7d1aa713b45f4ab1865666ee4164";
    private static final String DIYTRANSITION_URL_06 = "http://img01.sogoucdn.com/app/a/100520146/0303fb607eff3419c1ce6fc46e29ff7b";
    private static final String DIYTRANSITION_URL_07 = "http://img03.sogoucdn.com/app/a/100520146/86fdcb43d06c24ec662e089436b80563";
    private static final String DIYTRANSITION_URL_08 = "http://img03.sogoucdn.com/app/a/100520146/06b236b353cee21c483881bec1007655";
    private static final String DIYTRANSITION_URL_09 = "http://img04.sogoucdn.com/app/a/100520146/3235f69fac8f46c054a50a257bd5baee";
    private static final String DIYTRANSITION_URL_10 = "http://img01.sogoucdn.com/app/a/100520146/fa3da91e6a83c98f4b9078408e97d2b3";
	private static final String DIYTRANSITION_URL_11 = "http://img04.sogoucdn.com/app/a/100520146/f2d92303598b6e55f55460b74dc0581b";
	private static final String DIYTRANSITION_URL_12 = "http://img04.sogoucdn.com/app/a/100520146/0204f572352e553e488cd19002f1fa00";
	private static final String DIYTRANSITION_URL_13 = "http://img02.sogoucdn.com/app/a/100520146/48f6886a77088f25f9d3d0f819728142";
	private static final String DIYTRANSITION_URL_14 = "http://img03.sogoucdn.com/app/a/100520146/2ea3f9d48d303c5e4848523688952733";
	
    public static final String[] DIYTRANSITION_URLS = new String[]{
		DIYTRANSITION_URL_01, DIYTRANSITION_URL_02, DIYTRANSITION_URL_03
		, DIYTRANSITION_URL_04, DIYTRANSITION_URL_05, DIYTRANSITION_URL_06
		, DIYTRANSITION_URL_07, DIYTRANSITION_URL_08, DIYTRANSITION_URL_09
		, DIYTRANSITION_URL_10,DIYTRANSITION_URL_11,DIYTRANSITION_URL_12
		, DIYTRANSITION_URL_13,DIYTRANSITION_URL_14
    };
	
    // 2张图的随机图
    private static final String HOME_TWO_01 = "http://ojyz0c8un.bkt.clouddn.com/home_two_01.png";
    private static final String HOME_TWO_02 = "http://ojyz0c8un.bkt.clouddn.com/home_two_02.png";
    private static final String HOME_TWO_03 = "http://ojyz0c8un.bkt.clouddn.com/home_two_03.png";
    private static final String HOME_TWO_04 = "http://ojyz0c8un.bkt.clouddn.com/home_two_04.png";
    private static final String HOME_TWO_05 = "http://ojyz0c8un.bkt.clouddn.com/home_two_05.png";
    private static final String HOME_TWO_06 = "http://ojyz0c8un.bkt.clouddn.com/home_two_06.png";
    private static final String HOME_TWO_07 = "http://ojyz0c8un.bkt.clouddn.com/home_two_07.png";
    private static final String HOME_TWO_08 = "http://ojyz0c8un.bkt.clouddn.com/home_two_08.png";
    private static final String HOME_TWO_09 = "http://ojyz0c8un.bkt.clouddn.com/home_two_09.png";
    public static final String[] HOME_TWO_URLS = new String[]{
		HOME_TWO_01, HOME_TWO_02, HOME_TWO_03, HOME_TWO_04
		, HOME_TWO_05, HOME_TWO_06, HOME_TWO_07, HOME_TWO_08
		, HOME_TWO_09
    };

    /**
     * 一张图的随机图
     */
    private static final String HOME_ONE_1 = "http://ojyz0c8un.bkt.clouddn.com/home_one_1.png";

    private static ArrayList<String> oneList;

    private static ArrayList<String> getOneUrl() {
//        DebugUtil.error("oneList == null:   " + (oneList == null));
        if (oneList == null) {
            synchronized (ArrayList.class) {
                if (oneList == null) {
                    oneList = new ArrayList<>();
                    for (int i = 1; i < 13; i++) {
                        oneList.add("http://ojyz0c8un.bkt.clouddn.com/home_one_" + i + ".png");
                    }
                    return oneList;
                }
            }
        }
        return oneList;
    }

    // 一张图的随机图
    public static final String[] HOME_ONE_URLS = new String[]{
		getOneUrl().get(0), getOneUrl().get(1), getOneUrl().get(2), getOneUrl().get(3)
		, getOneUrl().get(4), getOneUrl().get(5), getOneUrl().get(6), getOneUrl().get(7)
		, getOneUrl().get(8), getOneUrl().get(9), getOneUrl().get(10), getOneUrl().get(11)
    };


    //-----------------------------------------------------------------------------
    // 1 -- 23
    private static final String HOME_SIX_1 = "http://ojyz0c8un.bkt.clouddn.com/home_six_1.png";
    private static ArrayList<String> sixList;

    private static ArrayList<String> getSixUrl() {
//        DebugUtil.error("sixList == null:   " + (sixList == null));
        if (sixList == null) {
            synchronized (ArrayList.class) {
                if (sixList == null) {
                    sixList = new ArrayList<>();
                    for (int i = 1; i < 24; i++) {
                        sixList.add("http://ojyz0c8un.bkt.clouddn.com/home_six_" + i + ".png");
                    }
                    return sixList;
                }
            }
        }
        return sixList;
    }

    // 六图的随机图
    public static final String[] HOME_SIX_URLS = new String[]{
		getSixUrl().get(0), getSixUrl().get(1), getSixUrl().get(2), getSixUrl().get(3)
		, getSixUrl().get(4), getSixUrl().get(5), getSixUrl().get(6), getSixUrl().get(7)
		, getSixUrl().get(8), getSixUrl().get(9), getSixUrl().get(10), getSixUrl().get(11)
		, getSixUrl().get(12), getSixUrl().get(13), getSixUrl().get(14), getSixUrl().get(15)
		, getSixUrl().get(16), getSixUrl().get(17), getSixUrl().get(18), getSixUrl().get(19)
		, getSixUrl().get(20), getSixUrl().get(21), getSixUrl().get(22)
    };
}

