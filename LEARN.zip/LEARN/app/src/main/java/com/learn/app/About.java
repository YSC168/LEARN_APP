package com.learn.app;

import android.content.*;
import android.net.*;
import android.os.*;
import android.support.design.widget.*;
import android.support.v7.app.*;
import android.support.v7.widget.*;
import android.view.*;
import android.widget.*;
import android.support.v7.widget.Toolbar;
import android.graphics.*;
import java.net.*;
import java.io.*;
import android.support.v4.view.*;
import com.learn.app.marqueeview.*;
import java.util.*;
import com.bumptech.glide.*;
public class About extends AppCompatActivity {
    private MarqueeView marqueeView1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
        setContentView(R.layout.about);
		int i = new Random().nextInt(ConstantsImageUrl.DIYTRANSITION_URLS.length);
		ImageView iv=(ImageView) findViewById(R.id.splash_iv_pic);
		Glide.with(this)
			.load(ConstantsImageUrl.DIYTRANSITION_URLS[i])
			.placeholder(R.drawable.error)
			.error(R.drawable.jiazai)
			.into(iv);
		marqueeView1 = (MarqueeView) findViewById(R.id.marqueeView1);
        marqueeView1.startWithText(getString(R.string.marquee_texts));
		Toolbar toolBar= (Toolbar) findViewById(R.id.toolbar);
		setSupportActionBar(toolBar);
		setActionBar();
		//toolBar.setLogo(R.mipmap.ic_launcher);//设置图标
		//toolBar.setTitle("关于软件");//设置主标题
		//getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		final ImageView imageView= (ImageView) findViewById(R.id.imageview);
		new Thread(new Runnable() {
				@Override
				public void run() {
					final Bitmap bitmap=getPicture("http://img03.sogoucdn.com/app/a/100520146/5cea1364aeea2f040108c302487c5fc2");
					try {
						Thread.sleep(2000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					imageView.post(new Runnable() {
							@Override
							public void run() {
								imageView.setImageBitmap(bitmap);
							}
						});
				}
			}).start();
	}
	
	public Bitmap getPicture(String path){
        Bitmap bm=null;
        try{
            URL url=new URL(path);
            URLConnection connection=url.openConnection();
            connection.connect();
            InputStream inputStream=connection.getInputStream();
            bm= BitmapFactory.decodeStream(inputStream);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return  bm;
    }

	@Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            //finishAfterTransition();
			onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }
    private void toHtml(String url) {
        Uri uri = Uri.parse(url);
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_VIEW);
        intent.setData(uri);
        startActivity(intent);
    }
	public void share(View v){
		Intent intent = new Intent(Intent.ACTION_SEND);
		intent.setType("text/plain"); 
		intent.putExtra(Intent.EXTRA_TEXT, "LEARN软件下载"+"\n"+"https://pan.baidu.com/s/1hudBhYG");
		intent.setType("text/plain");  //设置分享列表的标题，并且每次都显示分享列表
		startActivity(Intent.createChooser(intent, "分享软件"));
	
	}
	public void code(View v){
		toHtml("https://github.com/YSC168");
	}
	public void blog(View v){
		toHtml("http://www.baidu.com");
	}
	private void setActionBar() {
        setTitle(getResources().getString(R.string.about));
        try {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        } catch (NullPointerException e) {
            e.printStackTrace();
        }
    }
	@Override
    public void onBackPressed() {
        super.onBackPressed();
        // 添加返回过渡动画.
        overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);
    }
}
