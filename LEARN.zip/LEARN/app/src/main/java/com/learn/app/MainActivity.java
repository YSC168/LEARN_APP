package com.learn.app;

import android.os.*;
import android.support.design.widget.FloatingActionButton;
import com.learn.app.ENDownloadView;
import android.content.*;
import android.app.*;
import android.graphics.*;
import android.support.design.widget.*;
import android.support.v4.view.*;
import android.widget.*;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.util.Log;
import com.bumptech.glide.Glide;
import java.io.IOException;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;
import android.view.*;
import android.support.v4.app.*;
import com.learn.app.tab.*;
import java.util.*;
import java.text.*;
import android.support.v4.app.FragmentManager;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import android.media.*;
import android.webkit.*;
import android.net.*;
import android.content.pm.*;

import com.tencentqq.widget.QQDialog;
import com.tencentqq.widget.MenuDialog;
import com.tencentqq.widget.MenuDialog.OnSheetItemClickListener;
import com.tencentqq.widget.MenuDialog.setTextColor;


import android.provider.*;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.design.widget.Snackbar;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View.*;

import java.util.List;
import android.widget.TextView;
import android.preference.*;
import es.dmoral.toasty.*;
import java.io.*;
import com.learn.app.doodle.*;
import com.android.permission.*;
public class MainActivity extends AppCompatActivity
implements NavigationView.OnNavigationItemSelectedListener
{
	Calendar now = new GregorianCalendar();
	
	
	
	MediaPlayer mediaPlayer = new MediaPlayer();
	private IntentFilter intentFilter;
	private NetWorkChange networkchange;
	private DrawerLayout drawerLayout;
	private View headerLayout;
	private WebView mWebview;
	private FragmentManager fragmentManager;
	private NavigationView navigationView;
	private ImageView bingPicImg;
	
	public static  SharedPreferences sp;
	 private ColorSelectFragment colorSelectFragment;
	public static final int MSG_ONE = 1;
	
	private static final String ALIPAY_PACKAGE_NAME = "com.eg.android.AlipayGphone";

	private static final int OVERLAY_PERMISSION_REQ_CODE = 0;
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        sp = getSharedPreferences("config",Context. MODE_PRIVATE);    
		String selectcolor = sp.getString("color", ""); 
		//姨妈红
        if(selectcolor.equals("-769226")){
            setTheme(R.style.RedTheme);   
        }
        //原谅绿
        else if (selectcolor.equals("-11751600")){
            setTheme(R.style.GreenTheme);
        }
        //天空蓝
        else if(selectcolor.equals("-14575885")){
            setTheme(R.style.BlueTheme);
        }
        //卡其褐
        else if(selectcolor.equals("-8825528")){
            setTheme(R.style.BrowmTheme);
        }
        //太空灰
        else if(selectcolor.equals("-6381922")){
            setTheme(R.style.GreyTheme);
        }
        //哔哩粉
        else if(selectcolor.equals("-1499549")){
            setTheme(R.style.PinkTheme);
        }
        //基佬紫
        else if(selectcolor.equals("-6543440")){
            setTheme(R.style.PurpleTheme);
        }
        //橘子橙
        else if(selectcolor.equals("-26624")){
            setTheme(R.style.OrangeTheme);
        }
        //水鸭青
        else if(selectcolor.equals("-16738680")){
            setTheme(R.style.TealTheme);
        }
		String savePathDir = Environment.getExternalStorageDirectory() + "/YSC_APP/";
        File dirFile = new File(savePathDir);
        if (!dirFile.exists()) {
            boolean create = dirFile.mkdirs();
            if (!create) {
				ToastUtils.showToast(MainActivity.this, "创建文件夹失败！");
				
                return;
            }
        }
	
		
        super.onCreate(savedInstanceState);
		
        setContentView(R.layout.app_bar_main);	
		FloatWindowManager.getInstance().applyOrShowFloatWindow(MainActivity.this);

		
		
		intentFilter=new IntentFilter();
		intentFilter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
		networkchange=new NetWorkChange(MainActivity.this);
		//注册
		registerReceiver(networkchange,intentFilter);
	
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
		navigationView = (NavigationView) findViewById(R.id.nav_view) ;
		drawerLayout = (DrawerLayout) navigationView.findViewById(R.id.drawer_layout);
		headerLayout = navigationView.getHeaderView(0);
		WebView webView=(WebView) headerLayout.findViewById(R.id.webView);
		LayoutInflater inflater = LayoutInflater.from(this);
		View view = inflater.inflate(R.layout.webview, null);
		mWebview = (WebView) view.findViewById(R.id.webview);
		bingPicImg = (ImageView) headerLayout.findViewById(R.id.bing_pic_img);
		
		loadBingPic();
		bingPicImg.setOnClickListener(new OnClickListener()
			{
				@Override
				public void onClick(View v)
				{
					ToastUtils.showToast(MainActivity.this, "你点他它干嘛←_←");
					}
			});
		bingPicImg.setOnLongClickListener(new OnLongClickListener()
			{
				@Override
                public boolean onLongClick(View view) {
					CircularAnimUtil.startActivity(MainActivity.this, BingPic.class, view, R.color.colorPrimary);
                    return false;
			}});
	
		webView.setWebViewClient(new WebViewClient(){
				@Override
				public boolean shouldOverrideUrlLoading(WebView view, String url) {
					view.loadUrl(url);
					return true;
				}
			});
		webView.setBackgroundColor(0);
		webView.getSettings().setJavaScriptEnabled(true);
		webView.loadUrl("file:///android_asset/yiju.html");
		SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
		String bingPic = prefs.getString("bingpic", null);
        if (bingPic != null) {
			loadBingPic();
            Glide.with(this).load(bingPic).into(bingPicImg);
        } else {
            loadBingPic();
        }
		
		
		
        setSupportActionBar(toolbar);
		setActionBar();
	
        fragmentManager = getSupportFragmentManager();
		getSupportFragmentManager().beginTransaction().replace(R.id.frame_content, new Mainfirst()).commit();
		colorSelectFragment = new ColorSelectFragment();
	
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
		fab.setVisibility(View.GONE);
        fab.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					ToastUtils.showToast(MainActivity.this, "并没有什么用(๑>؂<๑）");
					
			}});

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
			this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
			drawer.setDrawerListener(toggle);
        toggle.syncState();
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
		if (id == R.id.tool){
			LayoutInflater inflater = LayoutInflater.from(this);
            View view = inflater.inflate(R.layout.setting, null);
			Switch mSwitch1 = (Switch) view.findViewById(R.id.settingSwitch1);
			Switch mSwitch2 = (Switch) view.findViewById(R.id.settingSwitch2);
			Switch mSwitch3 = (Switch) view.findViewById(R.id.settingSwitch3);
			Switch mSwitch4 = (Switch) view.findViewById(R.id.settingSwitch4);
			Switch mSwitch5 = (Switch) view.findViewById(R.id.settingSwitch5);
			Switch mSwitch6 = (Switch) view.findViewById(R.id.settingSwitch6);
			mSwitch1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
					@Override
					public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

						if (isChecked) {
							FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
							fab.setVisibility(View.VISIBLE);
						} else {
							FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
							fab.setVisibility(View.GONE);
						}
					}});
			mSwitch2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

					private Vibrator mVibrator;
					@Override
					public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

						if (isChecked) {
							mediaPlayer.reset();
							mediaPlayer = MediaPlayer.create(MainActivity.this,R.raw.pdd);
							mediaPlayer.setLooping(true);
							mediaPlayer.start();
						} else {
							mediaPlayer.stop();
						}
					}});
			mSwitch3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
					@Override
					public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

						if (isChecked) {
							Intent intent = new Intent(MainActivity.this, PictureService.class);
							startService(intent);
							finish();
							if (com.learn.app.test.testThread.checkAlertWindowsPermission(MainActivity.this))
							{
								Toast.makeText(MainActivity.this, "成功开启", Toast.LENGTH_LONG).show();
							}
							else
							{
								if(Build.VERSION.SDK_INT>=23)
								{
									if(Settings.canDrawOverlays(MainActivity.this))
									{
										//有悬浮窗权限开启服务绑定 绑定权限
										Intent intentf = new Intent(MainActivity.this, PictureService.class);
										startService(intentf);

									}else{
										//没有悬浮窗权限m,去开启悬浮窗权限
								try{
										Intent  intentf=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
										startActivityForResult(intentf, OVERLAY_PERMISSION_REQ_CODE);
									}catch (Exception e)
									{
										e.printStackTrace();
									}
								
									}
								} else{
									//默认有悬浮窗权限  但是 华为, 小米,oppo等手机会有自己的一套Android6.0以下  会有自己的一套悬浮窗权限管理 也需要做适配
									Intent intentf = new Intent(MainActivity.this, PictureService.class);
									startService(intentf);
								}
								Toast.makeText(MainActivity.this, "请开启悬浮窗权限", Toast.LENGTH_LONG).show();
							}	
						} else {
							Intent intent = new Intent(MainActivity.this, PictureService.class);
							stopService(intent);
						}
					}});
			mSwitch4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

					private Vibrator mVibrator;
					@Override
					public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

						if (isChecked) {
							mVibrator=(Vibrator)getApplication().getSystemService(Service.VIBRATOR_SERVICE);
							mVibrator.vibrate(new long[]{1000,1000,1000,1000},0);
						} else {
							mVibrator.cancel();
						}
					}});
			mSwitch5.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

					private Vibrator mVibrator;
					@Override
					public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

						if (isChecked) {
							mVibrator=(Vibrator)getApplication().getSystemService(Service.VIBRATOR_SERVICE);
							mVibrator.vibrate(new long[]{1,1000,1,1000},0);
						} else {
							mVibrator.cancel();
						}
					}});
			mSwitch6.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
					@Override
					public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

						if (isChecked) {
							setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);// 横屏

						} else {
							setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);// 竖屏
						}
					}});
			AlertDialog.Builder builder = new AlertDialog.Builder(this);

			builder.setView(view).setCancelable(true).setNegativeButton("关闭", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						dialog.cancel();//取消弹出框
					}});

			builder.show();
		}
		if (id == R.id.about){
			
			if (hasInstalledAlipayClient(MainActivity.this)) {
				OpenUtil.alipayDonate(this);
			} else {
				Toasty.error(MainActivity.this, "你没有安装支付宝！", Toast.LENGTH_LONG).show();
				
			}
			
            return true;
		}
		if (id == R.id.video){
			Intent intent=new Intent(MainActivity.this,Video.class);
			startActivity(intent,
						  ActivityOptions
						  .makeSceneTransitionAnimation(this).toBundle());
            return true;
		}
		if (id == R.id.other){
			Intent intent=new Intent(MainActivity.this,spjx.class);
			startActivity(intent,
						  ActivityOptions
						  .makeSceneTransitionAnimation(this).toBundle());
            return true;
		}
		if (id == R.id.tallybook){
			Intent intent=new Intent(MainActivity.this,Tallybook.class);
			startActivity(intent,
						  ActivityOptions
						  .makeSceneTransitionAnimation(this).toBundle());
            return true;
		}
		if (id == R.id.doodle){
			Intent intent=new Intent(MainActivity.this,DoodleViewActivity.class);
			startActivity(intent,
						  ActivityOptions
						  .makeSceneTransitionAnimation(this).toBundle());
            return true;
		}
		if (id == R.id.gsxt){
			setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR);// 传感器
            return true;
		}
		if (id == R.id.joke) {
			Intent intent = new Intent(this, NotificationActivity.class);
			PendingIntent pi = PendingIntent.getActivity(this, 0, intent, 0);
			NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
			Notification notification = new NotificationCompat.Builder(this)
				.setContentTitle("彩蛋")
				.setContentText("软件合集")
				.setWhen(System.currentTimeMillis())
				.setSmallIcon(R.drawable.aide)
				.setLargeIcon(BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher))
				.setContentIntent(pi)
                //        .setSound(Uri.fromFile(new File("/system/media/audio/ringtones/Luna.ogg")))
                //        .setVibrate(new long[]{0, 1000, 1000, 1000})
                        .setLights(Color.GREEN, 1000, 1000)
				.setDefaults(NotificationCompat.DEFAULT_ALL)
                //        .setStyle(new NotificationCompat.BigTextStyle().bigText("Learn how to build notifications, send and sync data, and use voice actions. Get the official Android IDE and developer tools to build apps for Android."))
				.setStyle(new NotificationCompat.BigPictureStyle().bigPicture(BitmapFactory.decodeResource(getResources(), R.drawable.aide)))
				.setPriority(NotificationCompat.PRIORITY_MAX)
				.build();
			manager.notify(1, notification);
			
            return true;
        }
        if (id == R.id.action_settings) {
			Intent intent=new Intent(MainActivity.this,Setting.class);
			startActivity(intent,
						  ActivityOptions
						  .makeSceneTransitionAnimation(this).toBundle());
            return true;
        }
	
        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.main) {
			//call();
			fragmentManager = getSupportFragmentManager();
			getSupportFragmentManager().beginTransaction().replace(R.id.frame_content, new Mainfirst()).commit();
            return true;
        }else if (id == R.id.use) {
			fragmentManager = getSupportFragmentManager();
			getSupportFragmentManager().beginTransaction().replace(R.id.frame_content, new Cardviewpager()).commit();
		}else if (id == R.id.music) {
			fragmentManager = getSupportFragmentManager();
			getSupportFragmentManager().beginTransaction().replace(R.id.frame_content, new Music()).commit();
			}
		else if (id == R.id.color) {
			fragmentManager = getSupportFragmentManager();
			getSupportFragmentManager().beginTransaction().replace(R.id.frame_content, new ColorMain()).commit();
        }else if (id == R.id.qrcode) {
			fragmentManager = getSupportFragmentManager();
			getSupportFragmentManager().beginTransaction().replace(R.id.frame_content, new Qrcode()).commit();
			}else if (id == R.id.theme) {
				showColorSelectDialog();
				
				//Intent intent=new Intent(MainActivity.this,ss.class);
				//startActivity(intent);


        } else if (id == R.id.webviewpick) {
		
			fragmentManager = getSupportFragmentManager();
			getSupportFragmentManager().beginTransaction().replace(R.id.frame_content, new Webview()).commit();
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
		
        return true;
    }
	private void showColorSelectDialog() {
		colorSelectFragment.show(fragmentManager, "dialog_color_select");
		colorSelectFragment.setOnOkClickListener(new ColorSelectFragment.onOkClickListener() {
				@Override
				public void onClick(View v, int color) {
					SharedPreferences.  Editor editor = sp.edit();        
					String a=(""+color);
					editor.putString("color", a);
					editor.commit();
					restart();
					Toasty.success(MainActivity.this, "主题切换成功",
								   Toast.LENGTH_SHORT).show();
					//Snackbar.make(bingPicImg, "保存在sdcard/YSC_APP/必应图片", Snackbar.LENGTH_LONG).show();
					//Toast.makeText(MainActivity.this, "主题切换成功！", Toast.LENGTH_SHORT).show();         
				}});
		
	}
	/**
     * 加载必应每日一图
     */
    private void loadBingPic() {
		SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
		String dbDate = prefs.getString("date","");
        if (!dbDate.equals(getCurrentDay())){
            loadBngPicByInt();
            SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(MainActivity.this).edit();
            editor.putString("date",getCurrentDay());
            editor.apply();
        }else {

            String bingPic = prefs.getString("bingpic", null);
            if (bingPic != null) {
                Glide.with(getApplicationContext()).load(bingPic).crossFade().centerCrop().into(bingPicImg);
            } else {
                loadBngPicByInt();
            }
        }
    }

    private void loadBngPicByInt() {
        String requestBingPic = "http://guolin.tech/api/bing_pic";
        HttpUtil.sendOkHttpRequest(requestBingPic, new Callback() {
				@Override
				public void onFailure(Call call, IOException e) {
					e.printStackTrace();
				}

				@Override
				public void onResponse(Call call, Response response) throws IOException {
					final String bingPic = response.body().string();
					SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(MainActivity.this).edit();
					editor.putString("bingpic", bingPic);
					editor.apply();
					runOnUiThread(new Runnable() {
							@Override
							public void run() {
								Glide.with(MainActivity.this).load(bingPic).into(bingPicImg);
							}
						});
				}
			});
    }
	private String getCurrentDay() {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat sf = new SimpleDateFormat("MM月dd日");
        Date date = calendar.getTime();
        String szDate = sf.format(date);
		
        return szDate;
    }

	/**
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		if (keyCode == KeyEvent.KEYCODE_BACK )
		{
			AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
			dialog.setTitle("提示");
			dialog.setMessage("确定退出？");
			dialog.setNegativeButton("取消", null);
			dialog.setPositiveButton("确认", new DialogInterface.OnClickListener(){

					@Override
					public void onClick(DialogInterface p1, int p2)
					{
						android.os.Process.killProcess(android.os.Process.myPid());
					}
				});
			//创建并显示对话框
			AlertDialog alertDialog = dialog.create();
			alertDialog.show();
			alertDialog.getButton(alertDialog.BUTTON_POSITIVE).setTextColor(0xffff4081);
	
		}

		return false;

	}
**/
   /** 
   public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode==event.KEYCODE_BACK)
        {
			Snackbar.make(this.findViewById(android.R.id.content),"是否退出程序",Snackbar.LENGTH_LONG).setAction("Yes", new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						android.os.Process.killProcess(android.os.Process.myPid());
					}
				}).show();
        }else if(keyCode==event.KEYCODE_MUTE)
        {
            drawerLayout.openDrawer(Gravity.LEFT);
        }

		return false;
    }
	**/
	public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode==event.KEYCODE_BACK)
        {
			final QQDialog dialog = new QQDialog(MainActivity.this,R.style.dialog_qq_animation);
			dialog.setViewLine(0xff00B4FF);
			dialog.setTitle("提示");
			dialog.setMessage("是否退出应用？");
			dialog.setCanceledOnTouchOutside(true);
			dialog.setCancelable(true);
			dialog.setPositiveButton("确定", new OnClickListener(){

					@Override
					public void onClick(View p1)
					{
						android.os.Process.killProcess(android.os.Process.myPid());
						System.exit(0);
						dialog.dismiss();
					}
				});
			dialog.show();
			}
		return false;
    }
 
	@Override
	protected void onDestroy()
	{
		// 程序关闭时取消注册
		super.onDestroy();
		unregisterReceiver(networkchange);
	}
	private void setActionBar() {
       // setTitle(getResources().getString(R.string.about));

        try {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        } catch (NullPointerException e) {
            e.printStackTrace();
        }
    }
	public static boolean hasInstalledAlipayClient(Context context) {
        PackageManager pm = context.getPackageManager();
        try {
            PackageInfo info = pm.getPackageInfo(ALIPAY_PACKAGE_NAME, 0);
            return info != null;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            return false;
        }
    }
	private void restart() {
        Intent intent = getIntent();
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }
}
