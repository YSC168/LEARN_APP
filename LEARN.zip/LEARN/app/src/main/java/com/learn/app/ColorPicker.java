package com.learn.app;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View.OnClickListener;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Button;
import android.widget.ImageView;
import android.graphics.Color;

public class ColorPicker extends Dialog implements OnClickListener, OnSeekBarChangeListener
{
    private OnColorChangeListener mOnColorChangeListener;
    private Context mContext;
    private int mColor, a, r, g, b;
    private TextView mTextView;
	private TextView cTextView;
    private SeekBar aSeekBar, rSeekBar, gSeekBar, bSeekBar;
    private Button pButton, nButton;
    private ImageView mImageView;
    public ColorPicker(Context context, OnColorChangeListener listener, int color) {
        super(context);
        mOnColorChangeListener = listener;
        mColor = color;
        mContext = context;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog);
        setTitle("颜色选择器");
        init();
    }
    @Override
    public void onClick(View p1)
    {
        // TODO: Implement this method
        switch (p1.getId()) {
            case R.id.pButton:
                mOnColorChangeListener.onColorChange(mColor);
                break;
            case R.id.nButton:
                break;
        }
        cancel();
    }
    @Override
    public void onStartTrackingTouch(SeekBar p1)
    {
        // TODO: Implement this method
    }
    @Override
    public void onStopTrackingTouch(SeekBar p1)
    {
        // TODO: Implement this method
    }
    @Override
    public void onProgressChanged(SeekBar p1, int p2, boolean p3)
    {
        // TODO: Implement this method
        switch (p1.getId()) {
            case R.id.aSeekBar:
                a = p2;
                break;
            case R.id.rSeekBar:
                r = p2;
                break;
            case R.id.gSeekBar:
                g = p2;
                break;
            case R.id.bSeekBar:
                b = p2;
                break;
        }
        mColor = Color.argb(a, r, g, b);
        colorChange();
    }
    private void init() {
        a = Color.alpha(mColor);r = Color.red(mColor);g = Color.green(mColor);b = Color.blue(mColor);
        mTextView = (TextView) findViewById(R.id.dialogTextView);
		cTextView = (TextView) findViewById(R.id.color);
        mImageView = (ImageView) findViewById(R.id.dialogImageView);
        colorChange();
        ((Button) findViewById(R.id.pButton)).setOnClickListener(this);
        ((Button) findViewById(R.id.nButton)).setOnClickListener(this);
        aSeekBar = (SeekBar) findViewById(R.id.aSeekBar);
        rSeekBar = (SeekBar) findViewById(R.id.rSeekBar);
        gSeekBar = (SeekBar) findViewById(R.id.gSeekBar);
        bSeekBar = (SeekBar) findViewById(R.id.bSeekBar);
        for (SeekBar s : new SeekBar[] {aSeekBar, rSeekBar, gSeekBar, bSeekBar}) {
            s.setOnSeekBarChangeListener(this);
        }
        aSeekBar.setProgress(a);rSeekBar.setProgress(r);gSeekBar.setProgress(g);bSeekBar.setProgress(b);
    }
    private void colorChange() {
        mTextView.setText(String.format("A: %d%nR: %d%nG: %d%nB: %d%n", a, r, g, b));
		cTextView.setText(String.format("#%02x%02x%02x%02x", a, r, g, b));
        mImageView.setBackgroundColor(mColor);
    }
    public interface OnColorChangeListener {
        public void onColorChange(int color);
    }
}

