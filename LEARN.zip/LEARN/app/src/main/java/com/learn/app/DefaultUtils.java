package com.learn.app;

public class DefaultUtils {
    public static final String textTheme[] = new String[]{
		"红", "绿", "蓝",
		"褐", "灰", "粉",
		"紫", "橙", "青"
    };
    public static final int color[] = new int[]{
		R.color.colorRedPrimary, R.color.colorGreenPrimary, R.color.colorBluePrimary,
		R.color.colorBrowmPrimary, R.color.colorGreyPrimary, R.color.colorPinkPrimary,
		R.color.colorPurplePrimary, R.color.colorOrangePrimary, R.color.colorTealPrimary
    };
}
