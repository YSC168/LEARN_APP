package com.learn.app.tab;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.content.*;
import android.app.*;
import android.widget.*;
import com.learn.app.*;
import android.graphics.*;
public class pager_window_01 extends Fragment {

    private static final String ARG_POSITION = "position";
    private int position;
	private TextView hTextView;
    public static pager_window_01 newInstance(int position) {
		
        pager_window_01 f = new pager_window_01();
        Bundle b = new Bundle();
        b.putInt(ARG_POSITION, position);
        f.setArguments(b);
        return f;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        position = getArguments().getInt(ARG_POSITION);
        View rootView = inflater.inflate(R.layout.layout_pager_window_01, container, false);
		
	
        switch (position) {
            case 0:
                break;
        }
		
		hTextView = (TextView)rootView.findViewById(R.id.name);
		hTextView.setTextColor(Color.RED);
		hTextView.setTypeface(FontManager.getInstance(getActivity().getAssets()).getFont("fonts/AmaticaSC-Regular.ttf"));
        return rootView;
    }
}

