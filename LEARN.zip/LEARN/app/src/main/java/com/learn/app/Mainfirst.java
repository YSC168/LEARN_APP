package com.learn.app;

import android.annotation.TargetApi;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.view.*;
import android.widget.*;
import android.app.*;
import android.os.*;
import android.content.*;
import android.net.*;
import android.util.*;
import android.support.design.widget.*;
import android.support.v4.view.*;
import com.learn.app.*;
import com.sunglab.bigbanghd.*;

public class Mainfirst extends Fragment  implements OnClickListener
{
	private Button beautiful;
	private Button other;
	private Button more;
	private Button about;
	private Button app;
	private Button jingzhi;
	private Button polypic;
	private Button magic;

    @Override
    public void onClick(View p1)
    {
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.main, container, false);
    }
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
	
        super.onActivityCreated(savedInstanceState);
		app = (Button) getActivity().findViewById(R.id.app);
        app.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					CircularAnimUtil.startActivity(getActivity(), AppActivity.class, view, R.color.colorPrimary);
					// 先将图片展出铺满，然后启动新的Activity
					//CircularAnimUtil.startActivity(MainActivity.this, EmptyActivity.class, view, R.mipmap.img_huoer_black);
					//Intent i = new Intent(getContext(), About.class);
					//startActivity(i);
				}
			});
		beautiful = (Button) getActivity().findViewById(R.id.beautiful);
        beautiful.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					CircularAnimUtil.startActivity(getActivity(), Beautiful.class, view, R.color.colorPrimary);
				}
			});
		other = (Button) getActivity().findViewById(R.id.other);
        other.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					CircularAnimUtil.startActivity(getActivity(), Ysc.class, view, R.color.colorPrimary);
				}
			});

		more = (Button) getActivity().findViewById(R.id.more);
        more.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					CircularAnimUtil.startActivity(getActivity(), More.class, view, R.color.colorPrimary);
				}
			});
		about = (Button) getActivity().findViewById(R.id.about);
        about.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					CircularAnimUtil.startActivity(getActivity(), About.class, view, R.color.colorPrimary);
				}
			});
		jingzhi = (Button) getActivity().findViewById(R.id.jing);
        jingzhi.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					CircularAnimUtil.startActivity(getActivity(), Jingzhi.class, view, R.color.colorPrimary);
				}
			});
		polypic = (Button) getActivity().findViewById(R.id.polypic);
        polypic.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					CircularAnimUtil.startActivity(getActivity(), Poly.class, view, R.drawable.jiazai);
				}
			});
		magic = (Button) getActivity().findViewById(R.id.magic);
        magic.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					CircularAnimUtil.startActivity(getActivity(), s.class, view, R.color.colorPrimary);
				}
			});
}
}
