package com.learn.app;

import android.annotation.TargetApi;
import android.app.FragmentManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.support.v7.app.AppCompatActivity;
import static android.preference.Preference.OnPreferenceClickListener;
import android.preference.*;
import android.support.v7.view.*;
import android.content.*;
import android.support.v4.content.*;
import android.support.v7.widget.Toolbar;
import android.view.*;
import android.provider.*;
import android.transition.Slide;
public class Setting extends AppCompatActivity {
	public static  SharedPreferences sp;
    private SettingsFragment mSettingsFragment;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
		sp = getSharedPreferences("config",Context. MODE_PRIVATE);    
        String selectcolor = sp.getString("color", ""); 
		//姨妈红
        if(selectcolor.equals("-769226")){
            setTheme(R.style.RedTheme);   
        }
        //原谅绿
        else if (selectcolor.equals("-11751600")){
            setTheme(R.style.GreenTheme);
        }
        //天空蓝
        else if(selectcolor.equals("-14575885")){
            setTheme(R.style.BlueTheme);
        }
        //卡其褐
        else if(selectcolor.equals("-8825528")){
            setTheme(R.style.BrowmTheme);
        }
        //太空灰
        else if(selectcolor.equals("-6381922")){
            setTheme(R.style.GreyTheme);
        }
        //哔哩粉
        else if(selectcolor.equals("-1499549")){
            setTheme(R.style.PinkTheme);
        }
        //基佬紫
        else if(selectcolor.equals("-6543440")){
            setTheme(R.style.PurpleTheme);
        }
        //橘子橙
        else if(selectcolor.equals("-26624")){
            setTheme(R.style.OrangeTheme);
        }
        //水鸭青
        else if(selectcolor.equals("-16738680")){
            setTheme(R.style.TealTheme);
        }
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setEnterTransition(new Slide().setDuration(500));
            getWindow().setReturnTransition(new Slide().setDuration(500));
            getWindow().setReenterTransition(new Slide().setDuration(500));
            getWindow().setExitTransition(new Slide().setDuration(500));
        }
        super.onCreate(savedInstanceState);	
        setContentView(R.layout.activity_setting);
		
		Toolbar toolBar= (Toolbar) findViewById(R.id.toolbar);
		setSupportActionBar(toolBar);
		setActionBar();
        if (savedInstanceState == null) {
            mSettingsFragment = new SettingsFragment();
            replaceFragment(R.id.settings_container, mSettingsFragment);
        }
    }
	@Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finishAfterTransition();
        }
        return super.onOptionsItemSelected(item);
    }
    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    public void replaceFragment(int viewId, android.app.Fragment fragment) {
        FragmentManager fragmentManager = getFragmentManager();
        fragmentManager.beginTransaction().replace(viewId, fragment).commit();
    }
    public static class SettingsFragment extends PreferenceFragment{
		private SharedPreferences.OnSharedPreferenceChangeListener mListenerOptions;	
        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            getPreferenceManager().setSharedPreferencesMode(MODE_WORLD_READABLE);
            addPreferencesFromResource(R.xml.pref_setting);//rrr
			Preference  ck= findPreference("checkbox");
			ck.setOnPreferenceClickListener(new OnPreferenceClickListener() {
					private static final boolean isChecked = false;
					@Override
					public boolean onPreferenceClick(Preference preference) {	
						
						Intent intent =  new Intent(Settings.ACTION_DISPLAY_SETTINGS);  
						startActivity(intent);
						return true;
					}
				});
			Preference fzgn = findPreference("fzgn");
			fzgn.setOnPreferenceClickListener(new OnPreferenceClickListener() {
					@Override
					public boolean onPreferenceClick(Preference pref) {
						Intent intent =  new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);  
						startActivity(intent);
						return true;}
			});
			Preference kf = findPreference("kf");
			kf.setOnPreferenceClickListener(new OnPreferenceClickListener() {
					@Override
					public boolean onPreferenceClick(Preference pref) {
						Intent intent =  new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS);  
						startActivity(intent);
						return true;}
				});
			Preference fx = findPreference("fx");
			fx.setOnPreferenceClickListener(new OnPreferenceClickListener() {
					@Override
					public boolean onPreferenceClick(Preference pref) {
						Intent intent = new Intent(Intent.ACTION_SEND);
						intent.setType("text/plain"); 
						intent.putExtra(Intent.EXTRA_TEXT, "LEARN软件下载"+"\n"+"https://pan.baidu.com/s/1hudBhYG");
						intent.setType("text/plain");  //设置分享列表的标题，并且每次都显示分享列表
						startActivity(Intent.createChooser(intent, "分享软件"));
						
						return true;}
				});
			Preference sjzt = findPreference("sjzt");
			sjzt.setOnPreferenceClickListener(new OnPreferenceClickListener() {
					@Override
					public boolean onPreferenceClick(Preference pref) {
						Intent intent =  new Intent(Settings.ACTION_DEVICE_INFO_SETTINGS);  
						startActivity(intent);
						return true;}
				});
			Preference sy = findPreference("sy");
			sy.setOnPreferenceClickListener(new OnPreferenceClickListener() {
					@Override
					public boolean onPreferenceClick(Preference pref) {
						Intent intent =  new Intent(Settings.ACTION_SOUND_SETTINGS);  
						startActivity(intent);
						return true;}
				});
			Preference yy = findPreference("yy");
			yy.setOnPreferenceClickListener(new OnPreferenceClickListener() {
					@Override
					public boolean onPreferenceClick(Preference pref) {
						Intent intent =  new Intent(Settings.ACTION_DREAM_SETTINGS);  
						startActivity(intent);
						return true;}
				});
			Preference ksqd = findPreference("ksqd");
			ksqd.setOnPreferenceClickListener(new OnPreferenceClickListener() {
					@Override
					public boolean onPreferenceClick(Preference pref) {
						Intent intent =  new Intent(Settings.ACTION_PRIVACY_SETTINGS);  
						startActivity(intent);
						return true;}
				});
     
        }
        //register preferences changes
        @Override
        public void onResume() {
            super.onResume();

            //register preferences changes
            getPreferenceManager().getSharedPreferences().registerOnSharedPreferenceChangeListener(mListenerOptions);
        }

        //unregister preferences changes
        @Override
        public void onPause() {
            getPreferenceManager().getSharedPreferences().unregisterOnSharedPreferenceChangeListener(mListenerOptions);
            super.onPause();
        }
    }
	private void setActionBar() {
        setTitle(getResources().getString(R.string.action_settings));
        try {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        } catch (NullPointerException e) {
            e.printStackTrace();
        }
    }
}

