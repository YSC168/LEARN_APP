package com.learn.app;

import android.*;
import android.content.*;
import android.content.pm.*;
import android.media.projection.*;
import android.os.*;
import android.support.v4.app.*;
import android.support.v4.content.*;
import android.support.v7.app.*;
import android.util.*;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.TextView;
import android.view.*;
import android.widget.*;
import android.widget.CompoundButton.*;
import android.app.*;
import android.graphics.*;
import android.graphics.drawable.*;
import info.hoang8f.widget.FButton;
import com.learn.app.*;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.content.SharedPreferences;
public class Video extends AppCompatActivity
{
	private TextView volume;//显示音量的文本框
	Audio MyAudio;//自己写的用于获取音量的类
	public MyHandler myHandler;//用于传递数据给主线程更新UI
	private static final int RECORD_REQUEST_CODE  = 101;
	private static final int STORAGE_REQUEST_CODE = 102;
	private static final int AUDIO_REQUEST_CODE   = 103;
	private MediaProjectionManager projectionManager;
	private MediaProjection mediaProjection;
	private RecordService recordService;
	private Button startBtn;
	public static boolean sy=false;
	Switch a;
	public static  SharedPreferences sp;
	@Override
	protected void onCreate ( Bundle savedInstanceState )
	{
		sp = getSharedPreferences("config",Context. MODE_PRIVATE);    
        String selectcolor = sp.getString("color", ""); 
		//姨妈红
        if(selectcolor.equals("-769226")){
            setTheme(R.style.RedTheme);   
        }
        //原谅绿
        else if (selectcolor.equals("-11751600")){
            setTheme(R.style.GreenTheme);
        }
        //天空蓝
        else if(selectcolor.equals("-14575885")){
            setTheme(R.style.BlueTheme);
        }
        //卡其褐
        else if(selectcolor.equals("-8825528")){
            setTheme(R.style.BrowmTheme);
        }
        //太空灰
        else if(selectcolor.equals("-6381922")){
            setTheme(R.style.GreyTheme);
        }
        //哔哩粉
        else if(selectcolor.equals("-1499549")){
            setTheme(R.style.PinkTheme);
        }
        //基佬紫
        else if(selectcolor.equals("-6543440")){
            setTheme(R.style.PurpleTheme);
        }
        //橘子橙
        else if(selectcolor.equals("-26624")){
            setTheme(R.style.OrangeTheme);
        }
        //水鸭青
        else if(selectcolor.equals("-16738680")){
            setTheme(R.style.TealTheme);
        }
		super.onCreate ( savedInstanceState );
		startService(new Intent(this, RecordService.class));
		projectionManager = (MediaProjectionManager) getSystemService ( MEDIA_PROJECTION_SERVICE );
		setContentView ( R.layout.video);
		volume=(TextView)findViewById(R.id.volume);
        myHandler=new MyHandler();
        MyAudio=new Audio(myHandler);
        MyAudio.getNoiseLevel();//获取音量
		Toolbar toolBar= (Toolbar) findViewById(R.id.toolbar);
		setSupportActionBar(toolBar);
		setActionBar();
		ImageView androidImageView = (ImageView) findViewById(R.id.android);
        Drawable drawable = androidImageView.getDrawable();
        if (drawable instanceof Animatable) {
            ((Animatable) drawable).start();
        }
		a=(Switch) findViewById(R.id.Switch);
		a.setOnCheckedChangeListener(new OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView,boolean isChecked) {
					if (isChecked) {
						sy=true;
					} else {
						sy=false;
					}
				}
			});
	
		startBtn = (Button) findViewById ( R.id.start_record );
		startBtn.setEnabled ( false );
		startBtn.setOnClickListener ( new View.OnClickListener ( ) {
				@Override
				public void onClick ( View v )
				{
					if ( RecordService.running )
					{
						recordService.stopRecord ( );
						startBtn.setText ("开始");
					}
					else
					{
						Intent captureIntent = projectionManager.createScreenCaptureIntent ( );
						startActivityForResult ( captureIntent, RECORD_REQUEST_CODE );
					}
				}
			} );
		if ( ContextCompat.checkSelfPermission ( Video.this, Manifest.permission.WRITE_EXTERNAL_STORAGE )
			!= PackageManager.PERMISSION_GRANTED )
		{
			ActivityCompat.requestPermissions ( this,
											   new String[] {Manifest.permission.WRITE_EXTERNAL_STORAGE}, STORAGE_REQUEST_CODE );
		}

		if ( ContextCompat.checkSelfPermission ( Video.this, Manifest.permission.RECORD_AUDIO )
			!= PackageManager.PERMISSION_GRANTED )
		{
			ActivityCompat.requestPermissions ( this,
											   new String[] {Manifest.permission.RECORD_AUDIO}, AUDIO_REQUEST_CODE );
		}

		Intent intent = new Intent ( this, RecordService.class );
		bindService ( intent, connection, BIND_AUTO_CREATE );
		if ( RecordService.running )
		{
			startBtn.setText ( "停止");
		}
		else
		{
			startBtn.setText("开始");
		}
    }
	@Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finishAfterTransition();
        }
        return super.onOptionsItemSelected(item);
    }
	@Override
	protected void onDestroy ( )
	{
		super.onDestroy ( );
		unbindService ( connection );
	}

	@Override
	protected void onActivityResult ( int requestCode, int resultCode, Intent data )
	{
		if ( requestCode == RECORD_REQUEST_CODE && resultCode == RESULT_OK )
		{
			mediaProjection = projectionManager.getMediaProjection ( resultCode, data );
			recordService.setMediaProject ( mediaProjection );
			recordService.startRecord ( );
			startBtn.setText ( "停止");
		}
	}

	@Override
	public void onRequestPermissionsResult ( int requestCode, String[] permissions, int[] grantResults )
	{
		super.onRequestPermissionsResult ( requestCode, permissions, grantResults );
		if ( requestCode == STORAGE_REQUEST_CODE || requestCode == AUDIO_REQUEST_CODE )
		{
			if ( grantResults [ 0 ] != PackageManager.PERMISSION_GRANTED )
			{
				finish ( );
			}
		}
	}

	private ServiceConnection connection = new ServiceConnection ( ) {
		@Override
		public void onServiceConnected ( ComponentName className, IBinder service )
		{
			DisplayMetrics metrics = new DisplayMetrics ( );
			getWindowManager ( ).getDefaultDisplay ( ).getMetrics ( metrics );
			RecordService.RecordBinder binder = (RecordService.RecordBinder) service;
			recordService = binder.getRecordService ( );
			recordService.setConfig ( metrics.widthPixels, metrics.heightPixels, metrics.densityDpi );
			startBtn.setEnabled ( true );
			startBtn.setText ( recordService.isRunning ( ) ? "停止": "开始" );
		}

		@Override
		public void onServiceDisconnected ( ComponentName arg0 )
		{}
	};
	private void setActionBar() {
        setTitle(getResources().getString(R.string.lp));
        try {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        } catch (NullPointerException e) {
            e.printStackTrace();
        }
    }
	class MyHandler extends Handler{
    	@Override
    	public void handleMessage(Message msg) {
    		// TODO Auto-generated method stub
    		/*
    		 * 当收到message的时候，这个函数被执行
    		 * 读取message的数据，并显示到文本框中
    		 */
    		super.handleMessage(msg);
    		Bundle b=msg.getData();
    		String sound=b.getString("sound");
    		Video.this.volume.setText(sound+"分贝");
    	}
    }
}

