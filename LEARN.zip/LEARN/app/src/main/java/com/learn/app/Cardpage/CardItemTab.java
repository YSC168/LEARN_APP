package com.learn.app.Cardpage;

public class CardItemTab {
    private int mTextResource;
    private int mTitleResource;
    public CardItemTab(int title, int text) {
        mTitleResource = title;
        mTextResource = text;
    }
    public int getText() {
        return mTextResource;
    }
    public int getTitle() {
        return mTitleResource;
    }
}

