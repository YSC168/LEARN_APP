package com.learn.app;

import android.content.Intent;
import android.os.Bundle;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.support.v4.app.*;
import android.view.View.*;
import android.view.*;
import com.learn.app.tab.*;
import android.support.v4.view.ViewPager;
import android.support.v4.app.FragmentManager;
import com.learn.app.Cardpage.*;

public class Cardviewpager extends  Fragment implements OnClickListener
{
	private ViewPager mViewPager;
	private CardPagerAdapter mCardAdapter;
	private ShadowTransformer mCardShadowTransformer;
  
	@Override
	public void onClick(View p1)
	{
		// TODO: Implement this method
	}
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
		return inflater.inflate(R.layout.cardviewpager, container, false);
	}
	@Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
		setHasOptionsMenu(true);
		mViewPager = (ViewPager) getActivity().findViewById(R.id.viewPager);
		mCardAdapter = new CardPagerAdapter();
        mCardAdapter.addCardItem(new CardItem(R.string.title_1, R.string.text_1));
        mCardAdapter.addCardItem(new CardItem(R.string.title_2, R.string.text_2));
        mCardAdapter.addCardItem(new CardItem(R.string.title_3, R.string.text_3));
        mCardAdapter.addCardItem(new CardItem(R.string.title_4, R.string.text_4));
		mCardAdapter.addCardItem(new CardItem(R.string.title_5, R.string.text_5));
        mCardShadowTransformer = new ShadowTransformer(mViewPager, mCardAdapter);
		mViewPager.setAdapter(mCardAdapter);
        mViewPager.setPageTransformer(false, mCardShadowTransformer);
        mViewPager.setOffscreenPageLimit(3);
		mCardShadowTransformer.enableScaling(true);
	}
}

