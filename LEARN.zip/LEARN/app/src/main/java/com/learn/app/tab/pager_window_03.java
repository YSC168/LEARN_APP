package com.learn.app.tab;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.learn.app.*;
import android.widget.*;
import android.content.*;
import com.learn.app.Cardpage.*;
import android.support.v4.view.*;

public class pager_window_03 extends Fragment {
	private ViewPager mViewPager;
	private CardPagerAdapterTab mCardAdapter;
	private ShadowTransformer mCardShadowTransformer;
    private static final String ARG_POSITION = "position";
    private int position;
	private Button btn_article;
    public static pager_window_03 newInstance(int position) {
        pager_window_03 f = new pager_window_03();
        Bundle b = new Bundle();
        b.putInt(ARG_POSITION, position);
        f.setArguments(b);
        return f;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        position = getArguments().getInt(ARG_POSITION);
        View rootView = inflater.inflate(R.layout.layout_pager_window_03, container, false);
        switch (position) {
            case 0:
                break;
        }
		mViewPager = (ViewPager) rootView.findViewById(R.id.viewPager);
		mCardAdapter = new CardPagerAdapterTab();
        mCardAdapter.addCardItem(new CardItemTab(R.string.poem_title_1, R.string.poem_text_1));
        mCardAdapter.addCardItem(new CardItemTab(R.string.poem_title_2, R.string.poem_text_2));
       mCardAdapter.addCardItem(new CardItemTab(R.string.poem_title_3, R.string.poem_text_3));
     //   mCardAdapter.addCardItem(new CardItemTab(R.string.title_4, R.string.text_1));
        mCardShadowTransformer = new ShadowTransformer(mViewPager, mCardAdapter);
		mViewPager.setAdapter(mCardAdapter);
        mViewPager.setPageTransformer(false, mCardShadowTransformer);
        mViewPager.setOffscreenPageLimit(3);
		mCardShadowTransformer.enableScaling(true);
        return rootView;
    }
}

