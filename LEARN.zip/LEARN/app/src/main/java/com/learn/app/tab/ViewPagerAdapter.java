package com.learn.app.tab;

import com.learn.app.*;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

public class ViewPagerAdapter extends FragmentPagerAdapter {

    final int PAGE_COUNT;
    private String titles[] ;
    public ViewPagerAdapter(FragmentManager fm, String[] titles2) {
        super(fm);
        titles=titles2;
        PAGE_COUNT =titles2.length;
    }

    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                return pager_window_01.newInstance(position);
            case 1:
                return pager_window_02.newInstance(position);
            case 2:
                return pager_window_03.newInstance(position);
        }
        return null;
    }

    public CharSequence getPageTitle(int position) {
        return titles[position];
    }

    @Override
    public int getCount() {
        return PAGE_COUNT;
    }
}

