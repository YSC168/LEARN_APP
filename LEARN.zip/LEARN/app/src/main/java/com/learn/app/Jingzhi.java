package com.learn.app;

import android.os.*;
import com.hanks.htextview.*;
import android.widget.*;
import android.view.View.*;
import android.view.*;
import android.util.*;
import android.graphics.*;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.*;
import android.widget.AdapterView.*;
import android.text.method.*;
import com.tencentqq.widget.*;
import android.content.SharedPreferences;
import android.content.*;
public class Jingzhi extends AppCompatActivity 
{
	private EditText ed1;
	private HTextView hTextView;
	private Button bt1;
	private Spinner spinner1,spinner2;
	private int jz1=2,jz2=2;
	public static  SharedPreferences sp;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
		sp = getSharedPreferences("config",Context. MODE_PRIVATE);    
        String selectcolor = sp.getString("color", ""); 
		//姨妈红
        if(selectcolor.equals("-769226")){
            setTheme(R.style.RedTheme);   
        }
        //原谅绿
        else if (selectcolor.equals("-11751600")){
            setTheme(R.style.GreenTheme);
        }
        //天空蓝
        else if(selectcolor.equals("-14575885")){
            setTheme(R.style.BlueTheme);
        }
        //卡其褐
        else if(selectcolor.equals("-8825528")){
            setTheme(R.style.BrowmTheme);
        }
        //太空灰
        else if(selectcolor.equals("-6381922")){
            setTheme(R.style.GreyTheme);
        }
        //哔哩粉
        else if(selectcolor.equals("-1499549")){
            setTheme(R.style.PinkTheme);
        }
        //基佬紫
        else if(selectcolor.equals("-6543440")){
            setTheme(R.style.PurpleTheme);
        }
        //橘子橙
        else if(selectcolor.equals("-26624")){
            setTheme(R.style.OrangeTheme);
        }
        //水鸭青
        else if(selectcolor.equals("-16738680")){
            setTheme(R.style.TealTheme);
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.jingzhi);
		Toolbar toolBar= (Toolbar) findViewById(R.id.toolbar);
		setSupportActionBar(toolBar);
		setActionBar();
		ed1 = (EditText)findViewById(R.id.mainMaterialEditText1);
		hTextView = (HTextView)findViewById(R.id.mainHTextView1);
		bt1 = (Button)findViewById(R.id.mainButton1);
		spinner1 = (Spinner) findViewById(R.id.spinner1);
		spinner2 = (Spinner) findViewById(R.id.spinner2);
		hTextView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 25);
		hTextView.reset(hTextView.getText());
		hTextView.setTextColor(Color.RED);
		hTextView.setBackgroundColor(Color.TRANSPARENT);
		hTextView.setTypeface(FontManager.getInstance(getAssets()).getFont("fonts/PoiretOne-Regular.ttf"));
        spinner1.setOnItemSelectedListener(new OnItemSelectedListener() {
				@Override
				public void onItemSelected(AdapterView<?> parent, View view, 
										   int pos, long id) {

					String[] languages = getResources().getStringArray(R.array.type);
					if(languages[pos].equals("2进制")){
						jz1=2;
						ed1.setKeyListener(DigitsKeyListener.getInstance("01")); 
					}else if(languages[pos].equals("8进制")){
						jz1=8;
						ed1.setKeyListener(DigitsKeyListener.getInstance("01234567")); 
					}else if(languages[pos].equals("10进制")){
						jz1=10;
						ed1.setKeyListener(DigitsKeyListener.getInstance("0123456789")); 
					}else if(languages[pos].equals("16进制")){
						jz1=16;
						ed1.setKeyListener(DigitsKeyListener.getInstance("0123456789ABCDEF")); 
					}

				}
				@Override
				public void onNothingSelected(AdapterView<?> parent) {
				}
			});

		spinner2.setOnItemSelectedListener(new OnItemSelectedListener() {
				@Override
				public void onItemSelected(AdapterView<?> parent, View view, 
										   int pos, long id) {

					String[] languages = getResources().getStringArray(R.array.type);
					if(languages[pos].equals("2进制")){
						jz2=2;
					}else if(languages[pos].equals("8进制")){
						jz2=8;
					}else if(languages[pos].equals("10进制")){
						jz2=10;
					}else if(languages[pos].equals("16进制")){
						jz2=16;
					}
				}
				@Override
				public void onNothingSelected(AdapterView<?> parent) {
				}
			});
		bt1.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					if(ed1.getText().toString().length()==0||ed1.getText().toString().equals(null)){
						QQToast.makeText(Jingzhi.this,"输入为空！");
					}else{
						ChangeText(HTextViewType.ANVIL,base.baseNum(ed1.getText().toString(),jz1,jz2));
					}
				}
			});
    }
	@Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }
	private void ChangeText(final HTextViewType Type,final String text){
		hTextView.setTypeface(FontManager.getInstance(getAssets()).getFont("fonts/PoiretOne-Regular.ttf"));
		hTextView.setAnimateType(Type);
		hTextView.animateText(text);
	}

	private void setActionBar() {
        setTitle(getResources().getString(R.string.jz));
        try {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        } catch (NullPointerException e) {
            e.printStackTrace();
        }
    }
	@Override
    public void onBackPressed() {
        super.onBackPressed();
        // 添加返回过渡动画.
        overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);
    }
}

