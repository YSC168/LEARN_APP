package com.download;

public interface DownloadProgressListener {
	public void onDownloadSize(int size);
}
